package TowerDefense;

import javax.swing.*;
import java.awt.*;

public class gameOver extends JPanel {
    private Image image,image1;
    private int x=250,y=150;
    public gameOver() {
        ImageIcon imageIcon = new ImageIcon("image/gameover.png");
        image = imageIcon.getImage();
        ImageIcon imageIcon1 = new ImageIcon("image/win.jpg");
        image1 = imageIcon1.getImage();
    }
    public void paint1(Graphics g){
        g.drawImage(image,x,y,  this);
    }
    public void paint2(Graphics g){
        g.drawImage(image1,x,y,  this);
    }
}

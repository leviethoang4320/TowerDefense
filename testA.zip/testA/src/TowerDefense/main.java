package TowerDefense;

import javax.swing.*;

public class main extends JFrame {

    public static void main(String[] args){
        final JFrame f = new JFrame();
        GameField gameField= new GameField();;
        f.setSize(1116,639);
        f.setTitle(" TOWER DEFENSE ");
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setLocation(150,0);
        f.add(gameField);
    }
}
